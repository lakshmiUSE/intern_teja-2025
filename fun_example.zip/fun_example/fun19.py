# Runtime Errors or Exceptions

# Exception Handling :  

#To handle teh exceptions we can use below statements or key words
"""
try  -->  Which ever the excpetional causing statements we need keep inside
try block 

except -->

Once exception arises what a action user or programmer can take , the code goes
inside except block 
"""
