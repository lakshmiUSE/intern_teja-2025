# What are the purpose of the function 
"""
Code - re-usability

Once we define a function we can call that function
where ever we require
"""
def display():
    print("Hi")
    print("Hello")
    print("Dont say Bye")
"""
display()
display()
display()
display()
"""
