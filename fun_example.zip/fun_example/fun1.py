#  Terminology

# Function Definition

# Function call

# Function parameters

# Function Return Value     
# How to defiend a function
"""
We can use def keyword to define a function
# SYNATX

def <function_name>(args):
    # st1
    # st2
    # :
    #
"""
# NOTE:  The function will execute only when we call that function
# We can call a function by uinsg function name
def display():
    print("Hello Welcome to python")

display()
