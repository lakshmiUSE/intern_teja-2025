x=[2,4,5,6]
x_shift=x[1:]+[x[0]]
print(x_shift)
