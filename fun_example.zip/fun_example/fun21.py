

def read_file(filepath):
    try:
        f = open(filepath, 'r')
        data = f.read()
        f.close()
        return data
    except:
        print(f"The file not found : {filepath}")


#path = "D:\\vdac_org\\sessions\\st23_yaswanth\\fun_example\\function coverd.txt"

path = input("Enter File path : ")
data = read_file(path)
print(data)
