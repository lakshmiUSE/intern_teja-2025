#  WAP find sum of two numbers
def add(x, y):
    c  = x+y
    print(c)


add(10,20)
