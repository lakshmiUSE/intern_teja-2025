# WAP implement basic caluculator application for two numbers

def add(x, y):
    c = x+y
    return c

def sub(x, y):
    c = x-y
    return c

def mul(x, y):
    c = x*y
    return c

def div(x, y):
    c = x//y
    return c

print((10, 20))

print(sub(100, 200))
    
print(mul(900, 200))


