
def add():
    
    r = add(1000, 2000)
    print(r)
add()
