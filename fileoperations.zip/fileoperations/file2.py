f=open("C:\\Users\\BHGYALAKSHMI\\OneDrive\\Desktop\\vedhu.txt")
text=f.read()
f.close()
print(type(text))
