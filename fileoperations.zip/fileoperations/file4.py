f=open("C:\\Users\\BHGYALAKSHMI\\OneDrive\\Desktop\\vedhu.txt",'a')

f.write("\n-----beautiful flower And the princess, though very unwilling, took him up in her hand, and put him upon the pillow of her own bed, where he slept all night long")
       

f.close()


"""
when we are opening a file in write mode ,if the file is not exist.then it will create new file

incase if the file is exit it will over write the content

if you wanted add new content then we need open in append mode
"""

